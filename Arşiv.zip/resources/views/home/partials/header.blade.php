<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1" name="viewport"/>
<meta content="" name="description"/>
<meta content="" name="author"/>
<meta content="{{ csrf_token() }}" name="_token"/>
<title>StarServer</title>

<link href="{{asset('./assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css"/>
<link href="{{asset('./assets/css/style.css')}}" rel="stylesheet" type="text/css"/>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

<link href="{{asset('./assets/adminLTE/AdminLTE.min.css')}}" rel="stylesheet" type="text/css"/>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>