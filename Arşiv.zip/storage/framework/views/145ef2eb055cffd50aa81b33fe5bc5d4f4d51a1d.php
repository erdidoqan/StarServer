<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('home.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>

    <body class="hold-transition login-page">

        <div class="page-container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <footer>
            <?php echo $__env->make('home.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </footer>

    </body>
</html>